/*****************************************************************
File: index.js
Author: Christian Josef Jurt
Description: This is an app that allows you to catelog gift ideas for your friends and family

Version: 0.0.1
Updated: March 31, 2017

*****************************************************************/

"use strict";

let people = [];

if(document.deviceready){
        	document.addEventListener('deviceready', init, false);
		}else{
        	document.addEventListener('DOMContentLoaded', init, false);
		}

function init() {
    
    if(!localStorage.getItem("giftr-jurt0001")){
     
        localStorage.setItem("giftr-jurt0001", people);
        console.log("local storage ket is now set");
        
    }
    
    else {

        let list = JSON.parse(localStorage.getItem("giftr-jurt0001"));
        showList(list);    //LINE THAT DOESN'T WORK.
        

        console.log("localStorage Exists");
   
    }   
}

function showlist(list){
    
    console.log("show list is working");
    
    for(i=0; i<list.length; i++){
        
        
        
        
    }
    
    
    
    
};




//var app = {
//    localNote: null,
//    init: function() {
//        try{
//            document.addEventListener('deviceready', this.onDeviceReady.bind(this), false);
//        }catch(e){
//            document.addEventListener('DOMContentLoaded', this.onDeviceReady.bind(this), false);
//            console.log('failed to find deviceready');
//        }
//    },
//    onDeviceReady: function() {
//        //set up event listeners and default variable values
//        window.addEventListener('push', app.pageChanged);
//        //cordova.plugins.notification.local
//        app.localNote = cordova.plugins.notification.local;
//        app.localNote.on("click", function (notification) {
//            
//        });
//        //show the list when loading
//        app.showList();
//    },
//    pageChanged: function(){
//        //user has clicked a link in the tab menu and new page loaded
//        //check to see which page and then call the appropriate function
//        
//    },
//    showList: function(){
//        let list = document.querySelector('#list-notify');
//    },
//    saveNew: function(ev){
//        ev.preventDefault();
//        //create a new notification with the details from the form
//        
//    }
//};
//
//app.init();